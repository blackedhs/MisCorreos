using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Configuration;
using System.Net.Configuration;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net.Mime;
using Microsoft.Win32;
namespace Gmail
{
    public partial class Form1 : Form
    {
        String path;
        MailMessage mail = new MailMessage();
        RegistryKey hklm;
       

        public Form1()
        {
            InitializeComponent();
            hklm = Registry.LocalMachine;
            hklm= hklm.OpenSubKey("SOFTWARE\\GmailClient",true );
            
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            backgroundWorker1.RunWorkerAsync();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                string userid = hklm.GetValue("uid").ToString();
                path = hklm.GetValue("path").ToString();
                TextBox5.Text = path;
                TextBox2.Text = userid + "@gmail.com";
            }
            catch
            {
                MessageBox.Show("Program is Corrupted, Reinstall it or Contact your vendor", "Critical Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                this.Dispose();
                Application.Exit();
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if(OpenFileDialog1.ShowDialog()== DialogResult.OK)
            {
                ListBox1.Items.Add(OpenFileDialog1.FileName);
            }
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog d1 = new OpenFileDialog();
             if(d1.ShowDialog() == DialogResult.OK)
             {
                path = d1.FileName;
                TextBox5.Text = d1.FileName;
                hklm.SetValue("path", TextBox5.Text);
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.ShowDialog();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            SmtpClient SmtpServer = new SmtpClient();
            SmtpServer.Credentials = new System.Net.NetworkCredential(hklm.GetValue("uid").ToString() + "@gmail.com", hklm.GetValue("passwd").ToString());
            SmtpServer.Port = 587;
            SmtpServer.Host = "smtp.gmail.com";
            SmtpServer.EnableSsl = true;
            mail = new MailMessage();
            String[] addr = TextBox1.Text.Split(',');
            try
            {
                mail.From = new MailAddress(hklm.GetValue("uid").ToString() + "@gmail.com", "Abhishek Sur", System.Text.Encoding.UTF8);
                Byte i;
                for (i = 0; i < addr.Length; i++)
                    mail.To.Add(addr[i]);
                mail.Subject = TextBox3.Text;
                mail.Body = TextBox4.Text;
                if (ListBox1.Items.Count != 0)
                {
                    for (i = 0; i < ListBox1.Items.Count; i++)
                        mail.Attachments.Add(new Attachment(ListBox1.Items[i].ToString()));
                }
                LinkedResource logo = new LinkedResource(path);
                logo.ContentId = "Logo";
                string htmlview;
                htmlview = "<html><body>" + TextBox4.Text + "<div style=\"width:100%\"><hr/><table border=1>" +
                            "<tr><td width=30%><img src=cid:Logo alt=\"" + hklm.GetValue("name").ToString() + "\" />" +
                            "</td><td><h1>" + hklm.GetValue("name").ToString() + "</h1><br/>" + hklm.GetValue("address").ToString() + "<br/>" +
                            "Web Developer<br/><b>Ph. " + hklm.GetValue("ph").ToString() + "</b><br/>" + hklm.GetValue("work").ToString() +
                            "<br/>" + hklm.GetValue("website").ToString() + "</td></tr>" +
                            "</table>" + hklm.GetValue("quote").ToString() + "<hr/><br/>";
                AlternateView alternateView1 = AlternateView.CreateAlternateViewFromString(htmlview, null, MediaTypeNames.Text.Html);
                alternateView1.LinkedResources.Add(logo);
                mail.AlternateViews.Add(alternateView1);
                mail.IsBodyHtml = true;
                mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                mail.ReplyTo = new MailAddress(TextBox1.Text);
                SmtpServer.Send(mail);
                MessageBox.Show("Your message is successfully sent");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AboutBox1 a = new AboutBox1();
            a.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Dispose();
            Application.Exit();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ChangeProfile c = new ChangeProfile();
            c.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Preview p = new Preview();
            p.Document = "<html><body>" + TextBox4.Text + "<br/>" +
                            "<div style=\"width:100%\"><hr/><table border=1 style=\"width:100%\">" +
                            "<tr><td width=30%><img style=\"width: 180px; height: 170px\" src=\"" +
                            this.path + "\" alt=\"" + hklm.GetValue("name").ToString() + "\" />" +
                            "</td><td><font size=5>" + hklm.GetValue("name").ToString() +
                            "</font><br/><b>Ph." + hklm.GetValue("ph").ToString() + "<br/>" +
                            "Web Developer</b><hr/> " + hklm.GetValue("work").ToString() +
                            "<br/>" + hklm.GetValue("address").ToString() +
                            "<br/>" + hklm.GetValue("website").ToString() + "</td></tr>" +
                            "</table><font color=\"teal\">" + hklm.GetValue("quote").ToString() +
                            "</font>";
            p.Text = "Mail Preview for : " + hklm.GetValue("name").ToString();
            p.ShowDialog();
        }

       
             
    }
}